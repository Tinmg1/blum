# Blum Bot

Auto Claim for Blum Telegram Bot

# Watch Video Tutorial
[Click Here](https://youtu.be/SoN_U7EO2XQ)

# Features

- [x] Auto Claim Farming 
- [x] Auto Start Farming
- [x] Auto Referral Bonus Claim
- [x] Auto Task Complete
- [x] Auto Play Game and Claim Reward
- [x] Auto Daily Bonus Claim
- [x] Multi Account Support

# Register

Click the following url to register : [Blum Bot](https://t.me/blum/app?startapp=tribe_sftearning_squad-ref_J6mrU1gUyy)

# How to Use
- [Windows](#windows)
- [Linux](#linux)
- [Termux](#termux)
## Windows 

1. Make sure you computer was installed python and git.
   
   python site : [https://python.org](https://python.org)
   
   git site : [https://git-scm.com/](https://git-scm.com/)

2. Clone this repository
   ```shell
   git clone https://github.com/BlackDragonHacker/Blum.git
   ```

3. goto Blum directory
   ```
   cd Blum
   ```

4. install the require library
   ```
   python -m pip install -r pip.txt
   ```

5. Edit `data.txt`, input you auth token in `data.txt` file

6. execute the main program 
   ```
   python Blum.py
   ```

## Linux

1. Make sure you computer was installed python and git.
   
   python
   ```shell
   sudo apt install python3 python3-pip
   ```
   git
   ```shell
   sudo apt install git
   ```

2. Clone this repository
   
   ```shell
   git clone https://github.com/BlackDragonHacker/Blum.git
   ```

3. goto Blum directory

   ```shell
   cd Blum
   ```

4. Install the require library
   
   ```
   python3 -m pip install -r pip.txt
   ```

5. Edit `data.txt`, input you auth token in `data.txt` file

6. execute the main program 
   ```
   python Blum.py
   ```

## Termux

1. Make sure you termux was installed python and git.
   
   python
   ```
   pkg install python
   ```

   git
   ```
   pkg install git
   ```

2. Clone this repository
   ```shell
   git clone https://github.com/BlackDragonHacker/Blum.git
   ```

3. goto Blum directory
   ```
   cd Blum
   ```

4. install the require library
   ```
   python -m pip install -r pip.txt
   ```
5. Edit `data.txt`, input you auth token in `data.txt` file
   
6. execute the main program 
   ```
   python Blum.py
   ```


# How to get auth token

`Application` < `Session Storage` < `__telegram__initParams` <`https://telegram.blum.codes` < `tgWebAppData`

then only copy `query_id` and  paste `query.txt` file

<a href="https://ibb.co/WHM0BZP"><img src="https://i.ibb.co/WHM0BZP/In-Shot-20240902-194551387.jpg" alt="In-Shot-20240902-194551387" border="0"></a>

# Thank you
